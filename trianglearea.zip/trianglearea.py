# Area of Triangle

land = int(input('Enter land : '))
height = int(input('Enter height : '))

area = 0.5 * land * height

print('The Area of rectangle is ',area)
print('The Area of rectangle is %s' % area)
print('The Area of rectangle is ' + str(area))
print('The Area of rectangle is {0}'.format(area))
print(f'The Area Of Triangle is {area}')